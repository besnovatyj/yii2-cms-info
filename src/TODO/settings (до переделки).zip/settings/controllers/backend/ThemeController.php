<?php

namespace modules\settings\controllers\backend;

use common\components\theme\Theme;
use common\helpers\ArrayExportHelper;
use DomainException;
use Exception;
use modules\settings\repositories\ThemesRepository;
use Yii;
use common\components\controller\BaseController;
use yii\helpers\VarDumper;
use yii\web\Response;

class ThemeController extends BaseController
{
    private ThemesRepository $themes;

    public function __construct(
        $id,
        $module,
        ThemesRepository $themes,
        $config = []
    )
    {
        parent::__construct($id, $module, $config);
        $this->themes = $themes;
    }

    public function actionIndex(): string
    {
        try {
            $themes = $this->themes->getThemes();
            return $this->render('index', [
                'themes' => $themes,
            ]);
        } catch (Exception $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return 'Error';
    }

    public function actionActivate($id): Response
    {
        try {
            $this->themes->activate($id);
        } catch (DomainException $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }

    public function actionViewPathMap()
    {
        try {
            $pathMap = (new Theme())->getPathMap();
            return '<pre>' . (new ArrayExportHelper())->export($pathMap) . '</pre>';
        } catch (DomainException $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }

    public function actionRenewPathMap(): Response
    {
        try {
            (new Theme())->renewPathMap();
            Yii::$app->session->setFlash('success', 'Карта путей сгенерирована!');
        } catch (DomainException $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }
}
