<?php

namespace modules\settings\controllers\backend;

use modules\settings\repositories\SystemInfoRepository;
use modules\settings\services\SysInfoService;
use Yii;
use yii\filters\VerbFilter;
use common\components\controller\BaseController;

class SysInfoController extends BaseController
{
    private $service = null;

    public function behaviors(): array
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'info' => ['POST'],
                ],
            ],
        ];
    }

    public function __construct(
        $id,
        $module,
        SysInfoService $service,
        array $config = []
    )
    {
        parent::__construct($id, $module, $config);
        $this->service = $service;
    }

    public function actionIndex(): string
    {
        if (Yii::$app->request->get('method') === 'sysinfo') {
            return json_encode([
                'stat' => SystemInfoRepository::getStat(),
                'stime' => date('Y-m-d H:i:s'),
                'uptime' => SystemInfoRepository::getUpTime(),
                'tempinfo' => SystemInfoRepository::getTempInfo(),
                'meminfo' => SystemInfoRepository::getMemInfo(),
                'loadavg' => SystemInfoRepository::getLoadAvg(),
                'diskinfo' => SystemInfoRepository::getDiskInfo(),
                'netdev' => SystemInfoRepository::getNetDev()
            ], JSON_THROW_ON_ERROR);
        }
        return $this->render('index', [
            'time_start' => microtime(true),
            'stat' => SystemInfoRepository::getStat(),
            'LC_CTYPE' => setlocale(LC_CTYPE, 0),
            'uname' => php_uname(),
            'stime' => date('Y-m-d H:i:s'),
            'distname' => SystemInfoRepository::getDistName(),
            'server_addr' => SystemInfoRepository::getServerAddr(),
            'remote_addr' => SystemInfoRepository::getRemoteAddr(),
            'uptime' => SystemInfoRepository::getUpTime(),
            'cpuinfo' => SystemInfoRepository::getCpuInfo(),
            'tempinfo' => SystemInfoRepository::getTempInfo(),
            'meminfo' => SystemInfoRepository::getMemInfo(),
            'loadavg' => SystemInfoRepository::getLoadAvg(),
            'diskinfo' => SystemInfoRepository::getDiskInfo(),
            'netdev' => SystemInfoRepository::getNetDev(),
        ]);
    }

    public function actionInfo(): string
    {
        return $this->render('index');
    }

}
