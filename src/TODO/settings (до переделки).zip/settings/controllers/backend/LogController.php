<?php


namespace modules\settings\controllers\backend;

use modules\settings\services\LogManageService;
use Exception;
use Yii;
use common\components\controller\BaseController;
use yii\helpers\VarDumper;
use yii\web\NotFoundHttpException;
use yii\web\Response;

class LogController extends BaseController
{
    private $service;

    public function __construct($id, $module, LogManageService $service, $config = [])
    {
        parent::__construct($id, $module, $config);
        $this->service = $service;
    }

    public function actionIndex(): string
    {
        return $this->render('index', [
            'dataProvider' => $this->service->getDataProvider('all')
        ]);
    }

    public function actionIndexHistory(): string
    {
        return $this->render('index-history', [
            'dataProvider' => $this->service->getDataProvider('history')
        ]);
    }

    public function actionIndexZip(): string
    {
        return $this->render('index-zip', [
            'dataProvider' => $this->service->getDataProvider('zip')
        ]);
    }

    public function actionView($slug)
    {
        try {
            $log = $this->service->find($slug);
            return Yii::$app->response->sendFile($log->getFilePath(), basename($log->getFilePath()), [
                'mimeType' => 'text/plain',
                'inline' => true
            ]);
        } catch (Exception $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }

    public function actionArchive($slug): Response
    {
        try {
            $this->service->archive($slug);
            Yii::$app->session->setFlash('success', 'Archive success');
            return $this->goReferer();
        } catch (Exception $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->refresh();
    }

    public function actionHistory($slug)
    {
        try {
            $data = $this->service->getHistory($slug);
            return $this->render('history', [
                'log' => $data['log'],
                'dataProvider' => $data['data_provider'],
                'fullSize' => $data['fullSize'],
            ]);
        } catch (NotFoundHttpException $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }

    public function actionDelete($slug, $since = null): Response
    {
        try {
            $this->service->deleteLog($slug, $since);
            Yii::$app->session->setFlash('success', 'Delete success.');
        } catch (Exception $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }

    public function actionDownload($slug): void
    {
        try {
            $log = $this->service->find($slug);
            Yii::$app->response->sendFile($log->getFilePath())->send();
        } catch (Exception $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
    }

    public function actionZip($slug): Response
    {
        try {
            $this->service->zip($slug);
            Yii::$app->session->setFlash('success', 'Zip success');
            return $this->redirect(['/settings/backend/log/index-zip']);
        } catch (Exception $e) {
            Yii::$app->errorHandler->logException($e);
            Yii::$app->session->setFlash('error', VarDumper::dumpAsString($e->getMessage()));
        }
        return $this->goReferer();
    }

    public function actionTail($slug, $line = 100, $stamp = null)
    {
        $log = $this->service->find($slug);
        $result = shell_exec("tail -n {$line} {$log->getFilePath()}");
        Yii::$app->response->format = Response::FORMAT_RAW;
        Yii::$app->response->headers->set('Content-Type', 'text/event-stream');
        return $result;

    }

}
