<?php

namespace modules\settings\controllers\backend;

use modules\settings\services\ClearService;
use Exception;
use Yii;
use yii\base\ExitException;
use yii\filters\VerbFilter;
use common\components\controller\BaseController;
use yii\web\Response;

class ClearController extends BaseController
{
    private ClearService|null $service;

    public function behaviors(): array
    {
        return [
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    '*' => ['POST'],
                ],
            ],
        ];
    }

    public function __construct($id, $module, ClearService $service, array $config = [])
    {
        parent::__construct($id, $module, $config);
        $this->service = $service;
    }

    /**
     * Очистка кеша
     * @throws ExitException
     */
    public function actionFlush(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->flush()) {
                    return [
                        'status' => 'success',
                        'message' => 'Кеш успешно очищен',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Очистка ресурсов фронтэнда
     * @throws ExitException
     */
    public function actionFrontAssets(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearFrontAssets()) {
                    return [
                        'status' => 'success',
                        'message' => 'Ресурсы фронтэнда очищены',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Очистка ресурсов бэкэнда
     * @throws ExitException
     */
    public function actionBackAssets(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearBackAssets()) {
                    return [
                        'status' => 'success',
                        'message' => 'Ресурсы бэкэнда очищены',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Очистка кеша статики
     * @throws ExitException
     */
    public function actionStaticCache(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearStaticCache()) {
                    return [
                        'status' => 'success',
                        'message' => 'Кеш статики очищен',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Очистка логов
     * @throws ExitException
     */
    public function actionLogs(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearLogs()) {
                    return [
                        'status' => 'success',
                        'message' => 'Все логи очищены',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Очистка отладочных писем
     * @throws ExitException
     */
    public function actionMails(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearMails()) {
                    return [
                        'status' => 'success',
                        'message' => 'Все отладочные письма удалены',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }


    /**
     * Очистка дампов debug-панели
     * @throws ExitException
     */
    public function actionDebug(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearDebug()) {
                    return [
                        'status' => 'success',
                        'message' => 'Все дампы debug-панели удалены',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Полная очистка
     * @throws ExitException
     */
    public function actionAll(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($this->service->clearAll()) {
                    return [
                        'status' => 'success',
                        'message' => 'Произведена полная очистка',
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }

    /**
     * Запрос занимаемого места
     * @throws ExitException
     */
    public function actionGetSize(): array
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $response = ['status' => 'error', 'message' => 'Отсутствует заголовок X-Requested-With-Fetch'];
        if ($this->isFetchRequest()) {
            try {
                if ($data = $this->service->getSize()) {
                    return [
                        'status' => 'success',
                        'data' => $data,
                    ];
                }
            } catch (Exception $e) {
                $this->ajaxError($e);
            }
        }
        return $response;
    }
}
