<?php

namespace modules\settings\services;

use modules\settings\repositories\DbLogRepository;
use modules\settings\repositories\DirRepository;
use Exception;
use Yii;

class ClearService
{
    public DirRepository|null $dirRepo;
    public DbLogRepository|null $dbRepo;

    public function __construct(DirRepository $repo, DbLogRepository $dbRepo)
    {
        $this->dirRepo = $repo;
        $this->dbRepo = $dbRepo;
    }

    public function flush(): bool
    {
        return Yii::$app->cache->flush();
    }

    /**
     * @throws Exception
     */
    public function clearFrontAssets(): bool
    {
        // Если ресурсы в виде ссылок, нет смысла их очищать,
        // но ссылки это вариант для `dev` режима, для `prod` лучше обычная публикация.
        if (Yii::$app->assetManager->linkAssets) {
            return true;
        }
        return $this->dirRepo->clearFrontAssets();
    }

    /**
     * @throws Exception
     */
    public function clearBackAssets(): bool
    {
        // Если ресурсы в виде ссылок, нет смысла их очищать,
        // но ссылки это вариант для `dev` режима, для `prod` лучше обычная публикация.
        if (Yii::$app->assetManager->linkAssets) {
            return true;
        }
        return $this->dirRepo->clearBackAssets();
    }

    /**
     * @throws Exception
     */
    public function clearStaticCache(): bool
    {
        return $this->dirRepo->clearStaticCache();
    }

    /**
     * @throws Exception
     */
    public function clearLogs(): bool
    {
        $flag1 = $this->dirRepo->clearLogs();
        $flag2 = $this->dbRepo->clearLogTable() >= 0; // Возвращает количество затронутых строк
        return $flag1 && $flag2;
    }

    /**
     * @throws Exception
     */
    public function clearMails(): bool
    {
        return $this->dirRepo->clearMail();
    }

    /**
     * @throws Exception
     */
    public function clearDebug(): bool
    {
        return $this->dirRepo->clearDebug();
    }

    /**
     * @throws Exception
     */
    public function clearAll(): bool
    {
        $res1 = $this->flush();
        $res2 = $this->clearFrontAssets();
        $res3 = $this->clearBackAssets();
        $res4 = $this->clearStaticCache();
        $res5 = $this->clearLogs();
        $res6 = $this->clearMails();
        $res7 = $this->clearDebug();
        return $res1 && $res2 && $res3 && $res4 && $res5 && $res6 && $res7;
    }

    public function getSize(): array
    {
        $tmp = [
            'static' => $this->dirRepo->getStaticCacheSize(), // размер директории статики
            'logs' => $this->dirRepo->getLogsSize(), // возвращает массив названий файлов лога и размер каждого из файлов
            'mails' => $this->dirRepo->getMailsCount(), // возвращает количество отладочных писем
            'debug' => $this->dirRepo->getDebugSize(), // возвращает количество файлов в панели Debug
            'db' => $this->dbRepo->getSizeDbTable(), // возвращает количество строк в БД логов
        ];
        return $tmp;
    }

}
