<?php

namespace modules\settings\services;

use modules\settings\repositories\FileLogRepository;
use DomainException;
use Exception;
use modules\settings\entities\Log;
use yii\data\ArrayDataProvider;
use yii\web\NotFoundHttpException;
use ZipArchive;

class LogManageService
{
    public FileLogRepository|null $repo;

    public function __construct(FileLogRepository $repo)
    {
        $this->repo = $repo;
    }

    public function getDataProvider($target = null): ArrayDataProvider
    {
        $models = match ($target) {
            'all' => $this->repo->findLogsMain(),
            'history' => $this->repo->findLogsHistory(),
            'zip' => $this->repo->findLogsZip(),
            null => throw new DomainException("Target '$target' is not a valid target type"),
        };

        return new ArrayDataProvider([
            'allModels' => $models,
            'sort' => [
                'attributes' => [
                    'name',
                    'size' => ['default' => SORT_DESC],
                    'updatedAt' => ['default' => SORT_DESC],
                ],
            ],
            'pagination' => ['pageSize' => 0],
        ]);
    }

    public function archive($slug): void
    {
        $log = $this->repo->getBySlug($slug);
        if (!rename($log->getFilePath(), $log->getPath() . '/' . $log->getBaseName() . date('YmdHis') . '.' . $log->getExtension())) {
            throw new \RuntimeException('Archive error');
        }
    }

    /**
     * @throws Exception
     */
    public function zip($slug): void
    {
        $log = $this->repo->getBySlug($slug);

        $zip = new ZipArchive();
        if ($zip->open($log->getFilePath() . '.zip', ZipArchive::CREATE) !== true) {
            throw new DomainException('Cannot open zipFile, do you have permission?');
        }
        $zip->addFile($log->getFilePath(), basename($log->getFilePath()));
        $zip->close();

        $this->repo->deleteFile($log->getFilePath());

    }

    /**
     * @param string $slug
     * @return array
     * @throws NotFoundHttpException
     */
    public function getHistory(string $slug): array
    {
        $data['log'] = $this->repo->getBySlug($slug);
        $allLogs = $this->repo->findHistoryBySlug($slug);

        $fullSize = 0;
        foreach ($allLogs as $log) {
            $fullSize = +$log->getSize();
        }
        $data['fullSize'] = $fullSize;

        $data['data_provider'] = new ArrayDataProvider([
            'allModels' => $allLogs,
            'sort' => [
                'attributes' => [
                    'filePath',
                    'size' => ['default' => SORT_DESC],
                    'updatedAt' => ['default' => SORT_DESC],
                ],
                'defaultOrder' => ['updatedAt' => SORT_DESC],
            ],
        ]);

        return $data;

    }

    /**
     * @param string $slug
     * @return Log
     */
    public function find(string $slug): Log
    {
        return $this->repo->getBySlug($slug);
    }

    /**
     * @param $slug
     * @param $since
     * @return bool
     * @throws Exception
     */
    public function deleteLog($slug, $since): bool
    {
        $log = $this->repo->getBySlug($slug);
        if (isset($since) && ($log->getUpdatedAt() != $since)) {
            throw new Exception('Delete error: file has updated.');
        }
        $this->repo->deleteFile($log->getFilePath());
        return true;
    }

}
