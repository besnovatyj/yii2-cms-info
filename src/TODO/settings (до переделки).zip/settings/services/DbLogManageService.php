<?php

namespace modules\settings\services;

use modules\settings\repositories\DbLogRepository;

class DbLogManageService
{
    public $logs;

    public function __construct(DbLogRepository $logs,)
    {
        $this->logs = $logs;
    }

    /**
     * @throws \yii\db\StaleObjectException
     * @throws \Throwable
     */
    public function remove($id): void
    {
        $log = $this->logs->get($id);
        $this->logs->remove($log);
    }

    /**
     * @throws \yii\db\Exception
     */
    public function clear(): void
    {
        $this->logs->clearLogTable();
    }

}
