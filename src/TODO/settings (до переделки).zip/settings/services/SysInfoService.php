<?php

namespace modules\settings\services;

class SysInfoService
{

}
