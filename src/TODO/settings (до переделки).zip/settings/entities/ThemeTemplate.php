<?php

namespace modules\settings\entities;

class ThemeTemplate
{
    public string|null $screenshot = null;
    public string|null $name = null;
    public bool|null $status = null;

    public function __construct($screenshot, $name, $status)
    {
        $this->screenshot = $screenshot;
        $this->name = $name;
        $this->status = $status;
    }

}
