<?php

use backend\widgets\grid\ActionColumn;
use modules\settings\entities\Log;
use yii\data\ArrayDataProvider;
use yii\grid\GridView;
use yii\helpers\Html;
use yii\web\View;

/**
 * @var View $this
 * @var \modules\settings\entities\Log $log
 * @var ArrayDataProvider $dataProvider
 * @var integer $fullSize
 */

$this->title = 'History('. $log->getName() . ')';
$this->params['breadcrumbs'][] = ['label' => 'Logs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$fullSizeFormat = \Yii::$app->formatter->asShortSize($fullSize);
$captionBtn = [];
if ($fullSize > 1) {
    $captionBtn[] = Html::a('zip all', ['zip-all', 'slug' => Yii::$app->request->get('slug')], ['class' => 'btn  btn-success btn-xs']);
    $captionBtn[] = Html::a('clean all', ['clean-all', 'slug' => Yii::$app->request->get('slug')], ['class' => 'btn  btn-danger btn-xs']);
}
$captionBtnStr = implode(' ', $captionBtn);
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?= $this->title ?></h3>
        <div class="card-tools">
        </div>
    </div>
    <div class="card-body">
        <?= GridView::widget([
            'tableOptions' => ['class' => 'table'],
            'options' => ['class' => 'grid-view table-responsive'],
            'dataProvider' => $dataProvider,
            'caption' => "full size: {$fullSizeFormat}. {$captionBtnStr}",
            'columns' => [
                [
                    'attribute' => 'fileName',
                    'format' => 'raw',
                    'value' => function (Log $hLog) {
                        return pathinfo($hLog->getFilePath(), PATHINFO_BASENAME);
                    },
                ], [
                    'attribute' => 'counts',
                    'format' => 'raw',
                    'value' => function (Log $log) {
                        return $this->render('_counts', ['log' => $log]);
                    },
                ], [
                    'attribute' => 'size',
                    'format' => 'shortSize',
                    'headerOptions' => ['class' => 'sort-ordinal'],
                ], [
                    'attribute' => 'updatedAt',
                    'format' => 'relativeTime',
                    'headerOptions' => ['class' => 'sort-numerical'],
                ], [
                    'class' => ActionColumn::class,
                    'template' => '{zip} {view} {delete} {download}',
                    'urlCreator' => function ($action, Log $log) {
                        return [$action, 'slug' => $log->getSlug(), 'stamp' => $log->getDateTimeStamp()];
                    },
                    'buttons' => [
                        'zip' => function ($url, Log $log) {
                            return Html::a('Zip', $url, [
                                'class' => 'btn  btn-xs btn-success',
                                'data' => ['method' => 'post', 'confirm' => 'Are you sure?'],
                            ]);
                        },
                        'view' => function ($url, Log $log) {
                            if ($log->isZip) {
                                return '';
                            }
                            return Html::a('View', $url, [
                                'class' => 'btn  btn-xs btn-primary',
                                'target' => '_blank',
                            ]);
                        },
                        'delete' => function ($url) {
                            return Html::a('Delete', $url, [
                                'class' => 'btn  btn-xs btn-danger',
                                'data' => ['method' => 'post', 'confirm' => 'Are you sure?'],
                            ]);
                        },
                        'download' => function ($url, Log $log) {
                            return Html::a('Download', $url, [
                                'class' => 'btn  btn-xs btn-secondary',
                            ]);
                        },
                    ],
                ],
            ],
        ]) ?>
    </div>
    <div class="card-footer clearfix">
    </div>
</div>
