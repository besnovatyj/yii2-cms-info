<?php

use modules\settings\entities\Log;
use yii\helpers\Html;
use yii\web\View;

/**
 * @var View $this
 * @var \modules\settings\entities\Log $log
 */
$levelClasses = [
    'trace' => 'bg-default',
    'info' => 'badge-info',
    'warning' => 'badge-warning',
    'error' => 'badge-danger',
];
$defaultLevelClass = 'bg-default';

foreach ($log->getCounts() as $level => $count) {
    $class = $levelClasses[$level] ?? $defaultLevelClass;
    echo Html::tag('span', $count, [
        'class' => 'badge ' . $class,
        'title' => $level,
    ]);
    echo ' ';
}
