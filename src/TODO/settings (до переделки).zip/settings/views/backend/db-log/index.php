<?php

use backend\widgets\grid\ActionColumn;
use modules\settings\entities\DbLog;
use modules\user\components\Helper;
use yii\bootstrap5\LinkPager;
use yii\data\ArrayDataProvider;
use yii\grid\GridView;
use yii\helpers\Html;
use yii\web\View;
use modules\settings\forms\backend\search\DbLogSearch;

/**
 * @var View $this
 * @var \modules\settings\forms\backend\search\DbLogSearch $searchModel
 * @var ArrayDataProvider $dataProvider
 */

$this->title = 'Logs';
$this->params['breadcrumbs'][] = 'Logs';
?>
<p>
    <?= Html::a('Clear log table', ['clear'], [
        'class' => 'btn  btn-danger',
        'data' => [
            'confirm' => 'Are you sure?',
            'method' => 'post',
        ],
    ]) ?>
</p>
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?= $this->title ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive">
        <?= GridView::widget([
            'options' => ['class' => 'table detail-view'],
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'layout' => "{summary}\n{items}",
            'columns' => [

                [
                    'attribute' => 'id',
                    'value' => static function (DbLog $model) {
                        return Html::a(Html::encode($model->id), ['view', 'id' => $model->id]);
                    },
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'level',
                    'filter' => $searchModel->levelsList(),
                    'value' => static function (DbLog $model) {
                        return \modules\settings\helpers\DbLogHelper::levelName($model->level);
                    },
                ],
                [
                    'attribute' => 'category',
                    'filter' => $searchModel->categoryList(),
                    'value' => static function (DbLog $model) {
                        return $model->category;
                    },
                ],
                [
                    'attribute' => 'log_time',
                    'value' => static function (DbLog $model) {
                        $label = Yii::$app->formatter->asDateTime($model->log_time);
                        return Html::a(Html::encode($label), ['view', 'id' => $model->id]);
                    },
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'prefix',
                    'label' => 'prefix ([IP][USER_ID][SESSION])',
                    'value' => static function (DbLog $model) {
                        return $model->prefix;
                    },
                    'format' => 'raw',
                ],
                ['class' => ActionColumn::class,
                    'template' => Helper::filterActionColumn(['view', 'update', 'delete',]),
                ],
            ],
        ]); ?>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
        <nav aria-label="" class="nav-pagination">
            <?= LinkPager::widget([
                'pagination' => $dataProvider->getPagination(),
            ]) ?>
        </nav>
    </div>
</div>
<!-- /.card -->
