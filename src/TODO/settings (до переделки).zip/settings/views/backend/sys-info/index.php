<?php
/* @var $this yii\web\View */
/* @var $statistics array */

$this->title = 'Информация о системе';
?>

<div class="admin-default-index">
    <h2>Hello, <?= isset(Yii::$app->user->identity->username) ? Yii::$app->user->identity->username : 'NoName' ?></h2>
</div>

<hr>

<div class="table-responsive">
    <table class="table table-bordered">
        <tr>
            <th colspan="4">Информация о сервере</th>
        </tr>
        <tr>
            <td>Имя хоста</td>
            <td colspan="3"><?php $os = explode(' ', $uname);
                echo $os[1]; ?>(<?= $server_addr; ?>
                )&nbsp;&nbsp;Ваш IP:<?= $remote_addr; ?></td>
        </tr>
        <tr>
            <td>Uname</td>
            <td colspan="3"><?= $uname ?></td>
        </tr>
        <tr>
            <td>Операционная система</td>
            <td><?= $distname ?></td>
            <td>Сервер</td>
            <td><?= $_SERVER['SERVER_SOFTWARE'] ?></td>
        </tr>
        <tr>
            <td>Язык</td>
            <td><?= $LC_CTYPE == 'C' ? 'POSIX' : $LC_CTYPE; ?></td>
            <td>Порт сервера</td>
            <td><?= $_SERVER['SERVER_PORT'] ?></td>
        </tr>
    </table>

    <table class="table table-bordered">
        <tr>
            <th colspan="4">Данные сервера в реальном времени</th>
        </tr>
        <tr>
            <td>Текущее время</td>
            <td><span id="stime"><?= $stime ?></span></td>
            <td>Аптайм сервера</td>
            <td><span id="uptime"><?= $uptime ?></span></td>
        </tr>
        <tr>
            <td>Модель CPU [<?= $cpuinfo['num'] ?>x]</td>
            <td colspan="3">
                <?= $cpuinfo['model']; ?>
                | Частота: <?= $cpuinfo['frequency'] ?> MHz
                | L2 Cache: <?= $cpuinfo['l2cache'] ?>
                | BogoMIPS<sup><a target="_blank"
                                  href="https://ru.wikipedia.org/wiki/BogoMIPS">?</a></sup>: <?= $cpuinfo['bogomips']; ?>
                ×<?= $cpuinfo['num'] ?>
            </td>
        </tr>
        <tr>
        </tr>
        <?php if (isset($tempinfo['cpu'])) : ?>
            <tr>
                <td>Температура CPU</td>
                <td><span id="cpu_temp"><?= $tempinfo['cpu']; ?></span></td>
                <td>Температура GPU</td>
                <td><span id="gpu_temp"><?= $tempinfo['gpu']; ?></span></td>
            </tr>
        <?php endif; ?>
        <tr>
            <td>Использование CPU</td>
            <td colspan="3">
                <span id="stat_user" class="text-info">0.0</span> user,
                <span id="stat_sys" class="text-info">0.0</span> sys,
                <span id="stat_nice">0.0</span> nice,
                <span id="stat_idle" class="text-info">99.9</span> idle,
                <span id="stat_iowait">0.0</span> iowait,
                <span id="stat_irq">0.0</span> irq,
                <span id="stat_softirq">0.0</span> softirq,
                <span id="stat_steal">0.0</span> steal
                <div class="progress">
                    <div id="stat_UserBar" class="progress-bar bg-success" role="progressbar"
                         style="width:1px">&nbsp;
                    </div>
                    <div id="stat_SystemBar" class="progress-bar bg-warning" role="progressbar"
                         style="width:0">&nbsp;
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td>Использование RAM</td>
            <td colspan="3">
                Физическая память <span id="meminfo_Total" class="text-info">
                    <?= $meminfo['memTotal'] ?></span>
                , Использовано <span id="meminfo_Used" class="text-success">
                    <?= $meminfo['memUsed'] ?></span>
                , Буфер <span id="meminfo_Buffers" class="text-pink">
                    <?= $meminfo['memBuffers'] ?> </span>
                , Кеш <span id="meminfo_Cached" class="text-warning">
                    <?= $meminfo['memCached'] ?></span>
                , Свободно <span id="meminfo_Free" class="text-info">
                    <?= $meminfo['memFree'] ?> </span>
                , Использовано <span id="meminfo_UsedPercent">
                    <?= $meminfo['memUsedPercent'] ?> </span>%<br>
                <div class="progress">
                    <div id="meminfo_UsedBar" class="progress-bar bg-success" role="progressbar"
                         style="width:<?= $meminfo['memUsedPercent'] ?>%" title="Используется"></div>
                    <div id="meminfo_BuffersBar" class="progress-bar bg-pink" role="progressbar"
                         style="width:<?= $meminfo['memBuffersPercent'] ?>%" title="Буферизировано"></div>
                    <div id="meminfo_CachedBar" class="progress-bar bg-warning" role="progressbar"
                         style="width:<?= $meminfo['memCachedPercent'] ?>%" title="Кешировано"></div>
                </div>
                <?php if ($meminfo['swapTotal'] > 0): ?>
                    SWAP：<span id="meminfo_swapTotal"><?= $meminfo['swapTotal']; ?></span>
                    , Использовано <span id="meminfo_swapUsed"><?= $meminfo['swapUsed'] ?></span>
                    , Свободно <span id="meminfo_swapFree"><?= $meminfo['swapFree'] ?></span>
                    , Использовано <span
                        id="meminfo_swapPercent"><?= $meminfo['swapPercent']; ?></span>%
                    <div class="progress">
                        <div id="meminfo_swapBar" class="progress-bar bg-danger" role="progressbar"
                             style="width:<?= $meminfo['swapPercent']; ?>%"></div>
                    </div>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td>Использование диска</td>
            <td colspan="3">
                Общий объём <?= $diskinfo['diskTotal']; ?>&nbsp;G，
                Использовано <span id="diskinfo_Used"><?= $diskinfo['diskUsed'] ?></span>&nbsp;G，
                Свободно <span id="diskinfo_Free"><?= $diskinfo['diskFree'] ?></span>&nbsp;G，
                Использовано <span id="diskinfo_Percent"><?= $diskinfo['diskPercent'] ?></span>%
                <div class="progress">
                    <div id="diskinfo_UsedBar" class="progress-bar bg-gray" role="progressbar"
                         style="width:<?= $diskinfo['diskPercent'] ?>%"></div>
                </div>
            </td>
        </tr>

        <tr>
            <td> Читать здесь подробнее, там еще что-то полезное написано:
                <a target="_blank" href="https://habr.com/ru/companies/vk/articles/335326/">https://habr.com/ru/companies/vk/articles/335326/</a>
            </td>
            <td><p>
                    Средние значения нагрузки в Linux — это «средние значения нагрузки системы», показывающие
                    потребность в исполняемых потоках (задачах) в виде усреднённого количества исполняемых и ожидающих
                    потоков. Это мера нагрузки, которая может превышать обрабатываемую системой в данный момент.
                    Большинство инструментов показывает три средних значения: для 1, 5 и 15 минут.
                </p>
                <p>
                    Некоторые интерпретации:
                    Если значения равны 0.0, то система в состоянии простоя.
                    Если среднее значение для 1 минуты выше, чем для 5 или 15, то нагрузка растёт.
                    Если среднее значение для 1 минуты ниже, чем для 5 или 15, то нагрузка снижается.
                    Если значения нагрузки выше, чем количество процессоров, то у вас могут быть проблемы с
                    производительностью (в зависимости от ситуации).

                </p>
            </td>
        </tr>
        <tr>
            <td>Средние значения нагрузки системы</td>
            <td colspan="3" class="text-danger"><span id="loadAvg"><?= $loadavg; ?></span></td>
        </tr>
    </table>

    <table class="table table-bordered">
        <tr>
            <th colspan="5">Загрузка сети</th>
        </tr>
        <?php foreach ($netdev as $dev => $info) : ?>
            <tr>
                <td style="width:13%"><?= $dev; ?> :</td>
                <td style="width:29%">Rx приём: <span class="text-info"
                                                      id="<?php printf('netdev_%s_human_rx', $dev); ?>"><?= $info['human_rx'] ?></span>
                </td>
                <td style="width:14%">Realtime: <span class="text-info"
                                                      id="<?php printf('netdev_%s_delta_rx', $dev); ?>">0B/s</span>
                </td>
                <td style="width:29%">Tx передача: <span class="text-info"
                                                         id="<?php printf('netdev_%s_human_tx', $dev); ?>"><?= $info['human_tx'] ?></span>
                </td>
                <td style="width:14%">Realtime: <span class="text-info"
                                                      id="<?php printf('netdev_%s_delta_tx', $dev); ?>">0B/s</span>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <table class="table table-bordered">
        <tr>
            <th colspan="12">PHP Info</th>
        </tr>
        <tr>
            <td style="width:16.7%">Версия</td>
            <td><?= phpversion(); ?></td>
            <td style="width:16.7%">Zend OpCache</td>
            <td><?= ini_get('opcache.enable') == 1 ? 'On' : 'Off'; ?></td>
        </tr>
        <tr>
            <td style="width:16.7%">Server API</td>
            <td><?= php_sapi_name(); ?></td>
            <td style="width:16.7%">Memory Limit</td>
            <td><?= ini_get('memory_limit'); ?></td>
        </tr>
        <tr>
            <td style="width:16.7%">POST Max Size</td>
            <td><?= ini_get('post_max_size'); ?></td>
            <td style="width:16.7%">Upload Max FileSize</td>
            <td><?= ini_get('upload_max_filesize'); ?></td>
        </tr>
        <tr>
            <td style="width:16.7%">Max Execution Time</td>
            <td><?= ini_get('max_execution_time'); ?>s</td>
            <td style="width:16.7%">Default Socket Timeout</td>
            <td><?= ini_get('default_socket_timeout'); ?>s</td>
        </tr>
    </table>
    <p>TODO: время выполнения скрипта взять из дебаг панели</p>
    <p>Processed in <?php printf('%0.1f', (microtime(true) - $time_start) * 1000); ?>
        ms, <?= round(memory_get_usage() / 1024, 0) . ' KB'; ?> memory usage.</p>
</div>

<script type="text/javascript">
    var dom = {
        element: null,
        get: function (o) {
            function F() {
            }

            F.prototype = this
            obj = new F()
            obj.element = (typeof o == "object") ? o : document.createElement(o)
            return obj
        },
        width: function (w) {
            if (!this.element)
                return
            this.element.style.width = w
            return this
        },
        html: function (h) {
            if (!this.element)
                return
            this.element.innerHTML = h
            return this
        }
    };

    $ = function (s) {
        return dom.get(document.getElementById(s.substring(1)))
    };

    $.getJSON = function (url, f) {
        var xhr = null;
        if (window.XMLHttpRequest) {
            xhr = new XMLHttpRequest();
        } else {
            xhr = new ActiveXObject('MSXML2.XMLHTTP.3.0');
        }
        xhr.open('GET', url + '&_=' + new Date().getTime(), true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                if (window.JSON) {
                    f(JSON.parse(xhr.responseText))
                } else {
                    f((new Function('return ' + xhr.responseText))())
                }
            }
        }
        xhr.send()
    }

    var stat = <?= json_encode($stat); ?>;
    var netdev = <?= json_encode($netdev); ?>;

    function getSysinfo() {
        $.getJSON('?method=sysinfo', function (data) {
            $('#uptime').html(data.uptime)
            $('#stime').html(data.stime)

            if (data.tempinfo.cpu)
                $('#cpu_temp').html(data.tempinfo.cpu + ' ℃')
            if (data.tempinfo.gpu)
                $('#gpu_temp').html(data.tempinfo.gpu + ' ℃')

            stat_total = 0
            for (var i = 0; i < data.stat.length; i++) {
                stat[i] = data.stat[i] - stat[i]
                stat_total += stat[i]
            }
            $("#stat_user").html((100 * stat[0] / stat_total).toFixed(1))
            $("#stat_nice").html((100 * stat[1] / stat_total).toFixed(1))
            $("#stat_sys").html((100 * stat[2] / stat_total).toFixed(1))
            $("#stat_idle").html((100 * stat[3] / stat_total).toFixed(1).substring(0, 4))
            $("#stat_iowait").html((100 * stat[4] / stat_total).toFixed(1))
            $("#stat_irq").html((100 * stat[5] / stat_total).toFixed(1))
            $("#stat_softirq").html((100 * stat[6] / stat_total).toFixed(1))
            $("#stat_steal").html((100 * stat[7] / stat_total).toFixed(1))
            $("#stat_UserBar").width(100 * (stat[0] + stat[1]) / stat_total + '%')
            $("#stat_SystemBar").width((100 * (stat_total - stat[0] - stat[1] - stat[3]) / stat_total) + '%')
            stat = data.stat

            $('#meminfo_Total').html(data.meminfo.memTotal)
            $('#meminfo_Used').html(data.meminfo.memUsed)
            $('#meminfo_Free').html(data.meminfo.memFree)
            $('#meminfo_UsedPercent').html(data.meminfo.memUsedPercent)
            $('#meminfo_UsedBar').width(data.meminfo.memUsedPercent + '%')
            $('#meminfo_BuffersBar').width(data.meminfo.memBuffersPercent + '%')
            $('#meminfo_CachedBar').width(data.meminfo.memCachedPercent + '%')

            $('#meminfo_swapTotal').html(data.meminfo.swapTotal)
            $('#meminfo_swapUsed').html(data.meminfo.swapUsed)
            $('#meminfo_swapFree').html(data.meminfo.swapFree)
            $('#meminfo_swapPercent').html(data.meminfo.swapPercent)
            $('#meminfo_swapBar').width(data.meminfo.swapPercent + '%')

            $('#diskinfo_Used').html(data.diskinfo.diskUsed)
            $('#diskinfo_Free').html(data.diskinfo.diskFree)
            $('#diskinfo_Percent').html(data.diskinfo.diskPercent)
            $('#diskinfo_UsedBar').width(data.diskinfo.diskPercent + '%')

            $('#loadAvg').html(data.loadavg)

            for (var dev in netdev) {
                var info = netdev[dev]
                $('#netdev_' + dev + '_human_rx').html(data.netdev[dev].human_rx)
                $('#netdev_' + dev + '_human_tx').html(data.netdev[dev].human_tx)
                $('#netdev_' + dev + '_delta_rx').html(((data.netdev[dev].rx - info.rx) / 1024).toFixed(2) + 'K/s')
                $('#netdev_' + dev + '_delta_tx').html(((data.netdev[dev].tx - info.tx) / 1024).toFixed(2) + 'K/s')
            }
            netdev = data.netdev
        });
    }

    window.onload = function () {
        setInterval(getSysinfo, 1000)
    }

</script>
