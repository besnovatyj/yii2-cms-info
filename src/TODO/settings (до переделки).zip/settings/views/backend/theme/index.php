<?php

use modules\settings\entities\ThemeTemplate;
use yii\helpers\StringHelper;
use yii\helpers\Url;

$this->title = 'Theming';
$this->params['breadcrumbs'][] = $this->title;
/** @var ThemeTemplate[] $themes */
?>
<p>
    <a class="btn btn-secondary"
       href="<?= Url::to(['/settings/backend/theme/renew-path-map']) ?>">
        Пересоздать карту представлений
    </a>
    <a class="btn btn-secondary" target="_blank"
       href="<?= Url::to(['/settings/backend/theme/view-path-map']) ?>">
        Просмотреть карту представлений (сделать в модальном окне)
    </a>
</p>
<div class="row">
    <?php foreach ($themes as $theme): ?>

        <?php if ($theme->status): ?>
            <div class="col-12 col-md-3">
                <div class="card">
                    <div class="card-header"><?= StringHelper::mb_ucfirst($theme->name) ?></div>
                    <img src="<?= $theme->screenshot ?>" class="card-img-top"
                         alt="<?= StringHelper::mb_ucfirst($theme->name) ?>">
                    <div class="card-footer">
                        <div class="d-grid gap-2">
                            <a href="<?= Url::to(['/settings/backend/theme/activate/', 'id' => $theme->name]) ?>"
                               class="btn  btn-danger disabled" type="button">Active</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="col-12 col-md-3">
                <div class="card">
                    <div class="card-header"><?= StringHelper::mb_ucfirst($theme->name) ?></div>
                    <a href="<?= Url::to(['/settings/backend/theme/activate/', 'id' => $theme->name]) ?>">
                        <img src="<?= $theme->screenshot ?>" class="card-img-top"
                             alt="<?= StringHelper::mb_ucfirst($theme->name) ?>">
                    </a>
                    <div class="card-footer">
                        <div class="d-grid gap-2">
                            <a href="<?= Url::to(['/settings/backend/theme/activate/', 'id' => $theme->name]) ?>"
                               class="btn btn-success" type="button">Activate</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
