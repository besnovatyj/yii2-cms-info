<?php

namespace modules\settings\repositories;

use modules\settings\entities\Log;
use Exception;
use FilesystemIterator;
use modules\settings\repositories\NotFoundException;
use RegexIterator;
use Yii;

class FileLogRepository
{
    public string|false $logsPath;

    public function __construct()
    {
        $this->logsPath = Yii::getAlias('@runtime/logs');
    }

    /**
     * @param string $slug
     * @return Log
     * @throws NotFoundException
     */
    public function getBySlug(string $slug): Log
    {
        /** @var \modules\settings\entities\Log[] $logs */
        $logs = $this->findLogsAll();
        foreach ($logs as $log) {
            if ($log->getSlug() == $slug) {
                return $log;
            }
        }
        throw new NotFoundException('File not found.');
    }

    public function findHistoryBySlug(string $slug): array
    {
        $logs = $this->findLogsHistory();
        $selectedLogs = [];
        foreach ($logs as $log) {
            if (str_contains($log->getSlug(), $slug)) {
                $selectedLogs[] = $log;
            }
        }
        return $selectedLogs;
    }

    public function findLogsAll(): array
    {
        $regexp = '/\.log/';
        $out = [];
        foreach ($this->getLogsIterator($regexp) as $obFile) {
            $out[] = new Log($obFile);
        }
        return $out;
    }

    /**
     * @return Log[]
     */
    public function findLogsHistory(): array
    {
        $regexp = '/[a-z]+\.[0-9]+\.log[\.(0-9)]?$/';
        $out = [];
        foreach ($this->getLogsIterator($regexp) as $obFile) {
            $out[] = new Log($obFile);
        }
        return $out;
    }

    /**
     * @return \modules\settings\entities\Log[]
     */
    public function findLogsZip(): array
    {
        $regexp = '/[a-z]+\.[0-9]+\.log\.zip$/';
        $out = [];
        foreach ($this->getLogsIterator($regexp) as $obFile) {
            $out[] = new Log($obFile);
        }
        return $out;
    }

    public function findLogsMain(): array
    {
        $regexp = '/[a-z,0-9]+\.log$/';
        $out = [];
        foreach ($this->getLogsIterator($regexp) as $obFile) {
            $out[] = new Log($obFile);
        }
        return $out;
    }

    protected function getLogsIterator($regexp): RegexIterator
    {
        $dir = $this->logsPath;
        $obIterator = new FilesystemIterator($dir);
        return new RegexIterator($obIterator, $regexp);
    }

    /**
     * @throws Exception
     */
    public function deleteFile(string $filePath): bool
    {
        if (!is_file($filePath)) {
            throw new \InvalidArgumentException('Файл не существует.');
        }
        if (!unlink($filePath)) {
            throw new Exception('Не удалось удалить файл: ' . $filePath);
        }
        return true;
    }

}
