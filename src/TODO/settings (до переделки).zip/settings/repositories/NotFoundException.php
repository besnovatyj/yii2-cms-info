<?php

namespace modules\settings\repositories;

class NotFoundException extends \DomainException
{

}
