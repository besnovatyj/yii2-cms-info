<?php

namespace modules\settings\repositories;

use common\helpers\FilesystemHelper;
use modules\settings\repositories\FileLogRepository;
use Yii;
use yii\base\ErrorException;
use yii\helpers\FileHelper;

class DirRepository
{
    private FileLogRepository|null $fileLogRepository;
    private string $dirHelper;
    private array $paths = [];

    public function __construct(FileLogRepository $fileLogRepository)
    {
        $this->dirHelper = FilesystemHelper::class;
        $this->fileLogRepository = $fileLogRepository;
        $this->paths = [
            'frontAssets' => Yii::getAlias('@frontend/pub/assets'),
            'backAssets' => Yii::getAlias('@backend/pub/assets'),
            'logs' => Yii::getAlias('@runtime/logs'),
            'css' => Yii::getAlias('@runtime/CSS'),
            'debug' => Yii::getAlias('@runtime/debug'),
            'html' => Yii::getAlias('@runtime/HTML'),
            'mail' => Yii::getAlias('@runtime/mail'),
            'uri' => Yii::getAlias('@runtime/URI'),
            'static' => Yii::getAlias('@static/cache'),
        ];
    }

    public function clearFrontAssets(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['frontAssets']);
    }

    public function clearBackAssets(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['backAssets']);
    }

    public function clearLogs(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['logs']);
    }

    public function clearCss(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['css']);
    }

    /**
     * @throws ErrorException
     */
    public function clearDebug(): bool
    {
//        return $this->dirHelper::deleteDirContents($this->paths['debug']);
        FileHelper::removeDirectory($this->paths['debug']);
        return true;
    }

    public function clearHtml(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['html']);
    }

    public function clearMail(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['mail']);
    }

    public function clearUri(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['uri']);
    }

    public function clearStaticCache(): bool
    {
        return $this->dirHelper::deleteDirContents($this->paths['static']);
    }

    public function getStaticCacheSize(): int
    {
        return $this->dirHelper::getDirSize($this->paths['static'], true);
    }

    public function getLogsSize(): array
    {
        $out = [];
        foreach ($this->fileLogRepository->findLogsAll() as $log) {
            $out[$log->getName()] = $log->getSize();
        }
        return $out;
    }

    public function getMailsCount(): int
    {
        return $this->dirHelper::countFiles($this->paths['mail']);
    }

    public function getDebugSize(): int
    {
        return $this->dirHelper::countFiles($this->paths['debug']);
    }


}
