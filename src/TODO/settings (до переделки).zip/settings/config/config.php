<?php
return [
    'id' => 'settings',
    'params' => [
        'directories' => true, // Если для работы модуля необходимы директории для статики
    ],
];
