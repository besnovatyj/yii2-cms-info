<?php
return [
    'tables' => [
        // https://www.yiiframework.com/doc/api/2.0/yii-db-querybuilder#getColumnType()-detail
        // @see \yii\db\QueryBuilder::getColumnType()
        '{{%log_logs}}' => [
            'columns' => [
                'id' => 'bigpk',
                'level' => 'integer NULL DEFAULT NULL',
                'category' => 'string NULL DEFAULT NULL',
                'log_time' => 'DOUBLE NULL DEFAULT NULL',
                'prefix' => 'text NULL DEFAULT NULL',
                'message' => 'text NULL DEFAULT NULL',
            ],
            'comments' => [ // Комментарии к столбцам
                'id' => 'bigpk',
                'level' => 'Уровень',
                'category' => 'Категория',
                'log_time' => 'Время',
                'prefix' => 'Префикс',
                'message' => 'Подробности',
            ],
            'comment' => 'Логи', // Комментарий к таблице
            'indexes' => [
                // [['column_1', 'column_2', ...], isUnique(false), isPK(false)]
                ['level'],
                ['category'],
            ],
        ],

    ],
    'initialData' => [],
];
