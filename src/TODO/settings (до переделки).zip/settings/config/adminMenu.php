<?php
return [
    'label' => 'Settings',
    'iconClass' => 'bi bi-sliders',
    'items' => [
        [
            'label' => 'Themes',
            'iconClass' => 'bi bi-palette me-1',
            'url' => ['/settings/backend/theme/index'],
            'active' => static function () {
                return str_contains(\Yii::$app->request->url, 'settings/backend/theme');
            },
        ], // Themes
        [
            'label' => 'System info',
            'iconClass' => 'bi bi-info-square me-1',
            'url' => ['/settings/backend/sys-info/index'],
            'active' => static function () {
                return str_contains(\Yii::$app->request->url, 'settings/backend/sys-info');
            },
        ], // System info
        [
            'label' => 'TXT Logs',
            'iconClass' => 'bi bi-filetype-txt me-1',
            'url' => ['/settings/backend/log/index'],
            'active' => static function () {
                return str_contains(\Yii::$app->request->url, 'settings/backend/log');
            },
        ],
        [
            'label' => 'DB Logs',
            'iconClass' => 'bi bi-database-exclamation me-1',
            'url' => ['/settings/backend/db-log/index'],
            'active' => static function () {
                return str_contains(\Yii::$app->request->url, 'settings/backend/db-log');
            },
        ],
    ],
];
