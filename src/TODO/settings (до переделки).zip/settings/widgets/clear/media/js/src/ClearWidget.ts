import {ApiService} from './ApiService';
import {CustomError, ErrorHandler} from './ErrorHandler';

class ClearWidget {
    private element: HTMLElement;
    private readonly endpoints: Endpoints;
    private apiService: ApiService;
    private errorHandler: ErrorHandler;

    constructor(element: HTMLElement) {
        if (!element.dataset.endpoints) {
            throw new CustomError('constructor', 'Endpoints dataset is missing', {});
        }

        this.element = element;
        this.endpoints = JSON.parse(element.dataset.endpoints) as Endpoints;
        this.apiService = new ApiService();
        this.errorHandler = new ErrorHandler();
        this.initialize();
    }

    private async initialize(): Promise<void> {
        await this.fetchAndRenderSize();
        this.renderButtons();
    }

    private renderButtons(): void {
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'button-container mb-3 d-flex gap-2 flex-wrap';

        const additionalActions: Partial<Record<keyof Endpoints, string>> = {
            flush: 'Очистить кеш',
            all: 'Полная очистка',
        };

        Object.entries(additionalActions).forEach(([key, label]) => {
            const endpointKey = key as keyof Endpoints;
            if (this.endpoints[endpointKey]) {
                const button = document.createElement('button');
                button.textContent = label ?? 'label_is_empty(error...)';
                button.className = 'btn btn-primary';
                button.addEventListener('click', async () => {
                    await this.handleButtonClick(this.endpoints[endpointKey] as string, label ?? 'label_is_empty(error...)');
                });
                buttonContainer.appendChild(button);
            }
        });

        this.element.appendChild(buttonContainer);
    }

    private async handleButtonClick(url: string, label: string): Promise<void> {
        try {
            const response = await this.apiService.post(url);
            if (response.status === 'success') {
                showAlert({
                    message: `${label}: ${response.message}`,
                    type: 'success',
                    duration: 3000,
                });
                await this.fetchAndRenderSize();
            } else {
                throw new CustomError(String(response.message), String(response.data?.message), response);
            }
        } catch (error) {
            this.errorHandler.handleError(error, 'handleButtonClick');
        }
    }

    private async fetchAndRenderSize(): Promise<void> {
        try {
            const response: ErrorResponse | NormalResponse = await this.apiService.post(this.endpoints['get-size']);
            if (response.status === 'success') {
                this.renderSizeTable(response.data as SizeData);
            } else {
                throw new CustomError(String(response.message), String(response.data?.message ?? ''), response);
            }
        } catch (error) {
            this.errorHandler.handleError(error, 'fetchAndRenderSize');
        }
    }

    private renderSizeTable(data: SizeData): void {
        const existingTable = this.element.querySelector('.size-table');
        if (existingTable) {
            existingTable.remove();
        }

        const tableContainer = document.createElement('div');
        tableContainer.className = 'size-table mb-3';

        const table = document.createElement('table');
        table.className = 'table table-bordered table-hover';

        const thead = document.createElement('thead');
        thead.innerHTML = `
      <tr>
        <th scope="col">Элемент</th>
        <th scope="col">Разм./Кол-во</th>
        <th scope="col">Действие</th>
      </tr>
    `;
        table.appendChild(thead);

        const tbody = document.createElement('tbody');

        const itemDetails: Record<string, ItemDetail> = {
            static: {name: 'Кеш статики', endpoint: this.endpoints['static-cache']!},
            logs: {name: 'Логи', endpoint: this.endpoints['logs']!},
            mails: {name: 'Отладочные письма', endpoint: this.endpoints['mails']!},
            debug: {name: 'Дампы дебага', endpoint: this.endpoints['debug']!},
            frontAssets: {name: 'Ресурсы фронтэнда', endpoint: this.endpoints['front-assets']!},
            backAssets: {name: 'Ресурсы бэкэнда', endpoint: this.endpoints['back-assets']!},
        };

        Object.entries(data).forEach(([key, value]) => {
            const detail = itemDetails[key];
            if (!detail) return;

            const row = document.createElement('tr');

            if (key === 'logs' && typeof value === 'object' && value !== null) {
                const totalSize = Object.values(value as Record<string, number>).reduce((sum: number, size: number) => sum + size, 0);
                row.innerHTML = `
          <td>${detail.name}</td>
          <td>${this.formatSize(totalSize)}</td>
          <td>
            <button class="btn btn-sm btn-danger clear-item" data-url="${detail.endpoint}" data-label="${detail.name}">
              Очистить
            </button>
          </td>
        `;
            } else {
                row.innerHTML = `
          <td>${detail.name}</td>
          <td>${['mails', 'debug', 'db'].includes(key) ? value : this.formatSize(value as number)}</td>
          <td>
            <button class="btn btn-sm btn-danger clear-item" data-url="${detail.endpoint}" data-label="${detail.name}">
              Очистить
            </button>
          </td>
        `;
            }
            tbody.appendChild(row);
        });

        table.appendChild(tbody);
        tableContainer.appendChild(table);
        this.element.insertBefore(tableContainer, this.element.firstChild);

        tableContainer.querySelectorAll('.clear-item').forEach(button => {
            button.addEventListener('click', async () => {
                const url = button.getAttribute('data-url')!;
                const label = button.getAttribute('data-label')!;
                await this.handleButtonClick(url, label);
            });
        });
    }

    private formatSize(bytes: number): string {
        if (typeof bytes !== 'number') return String(bytes);
        const units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
        let size = bytes;
        let unitIndex = 0;

        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }

        return `${size.toFixed(2)} ${units[unitIndex]}`;
    }
}

// Инициализация виджета
document.addEventListener('DOMContentLoaded', () => {
    const widget = document.querySelector('.settings-module-clear-widget');
    if (widget instanceof HTMLElement) {
        new ClearWidget(widget);
    }
});

export default ClearWidget;
