class ApiService {
    private getCsrfToken(): string {
        const tokenElement = document.head.querySelector('[name="csrf-token"]');
        if (!tokenElement) {
            throw new Error('CSRF token not found');
        }
        return tokenElement.getAttribute('content')!;
    }

    private getRequestHeaders(): HeadersInit {
        return {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': this.getCsrfToken(),
            'X-Requested-With-Fetch': 'true',
            'Content-Type': 'application/json',
        };
    }

    async post(url: string, body?: unknown): Promise<ErrorResponse | NormalResponse> {
        const response = await fetch(url, {
            method: 'POST',
            headers: this.getRequestHeaders(),
            body: body ? JSON.stringify(body) : undefined,
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return response.json();
    }
}

export {ApiService};
