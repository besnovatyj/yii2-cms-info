import {defineConfig} from 'vite';

export default defineConfig({
    build: {
        outDir: 'dist', // Выходная папка для собранных файлов.
        assetsDir: 'assets', // Папка для статических ресурсов (CSS, изображения).
        minify: true, // Минифицирует выходной код для продакшн.
        sourcemap: true, // Включает генерацию source maps
        rollupOptions: {
            input: { // Указывает точки входа для отдельных скриптов.
                index: 'src/ClearWidget.ts'
                // clearWidget: 'src/ClearWidget.ts'
                // Добавьте другие скрипты, если нужно, например:
                // anotherWidget: 'src/AnotherWidget.ts'
            },
            output: { // Именует выходные файлы по ключам из input (например, clearWidget.js).
                entryFileNames: '[name].js', // Создаёт clearWidget.js, anotherWidget.js и т.д.
                format: 'esm', // Создаёт ES-модули для <script type="module">.
            }
        }
    }
});
