// global.d.ts

// Интерфейс для конфигурации showAlert
interface ShowAlertConfig {
    message: string; // Текст сообщения (обязательное поле)
    type: 'success' | 'error' | 'warning' | 'info'; // Тип сообщения (обязательное поле)
    duration?: number; // Длительность отображения в миллисекундах (необязательное поле)
}

// Объявление типа для функции showAlert
declare function showAlert(config: ShowAlertConfig): void;

interface Endpoints {
    'get-size': string;
    flush?: string;
    all?: string;
    'static-cache'?: string;
    logs?: string;
    mails?: string;
    debug?: string;
    'front-assets'?: string;
    'back-assets'?: string;
}

interface SizeData {
    [key: string]: number | Record<string, number>;
}

interface ItemDetail {
    name: string;
    endpoint: string;
}

type ErrorResponse = {
    status: 'error',
    message: number | string,   // PHP $error->getCode();
    data: {
        message: string,        // PHP $error->getMessage();
        file: string,           // PHP $error->getFile();
        line: number,           // PHP $error->getLine();
        code: number | string,  // PHP $error->getCode();
        trace: string,          // PHP $error->getTraceAsString();
    }
};

type NormalResponse = {
    status: 'success',
    data: object,
    method: string, // Метод бэкэнда называется так же
    message: string,
}
