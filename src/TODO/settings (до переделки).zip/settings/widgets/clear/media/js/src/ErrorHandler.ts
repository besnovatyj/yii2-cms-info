export class CustomError {
    constructor(public name: string, public message: string, public data: object) {
    }
}

class ErrorHandler {
    handleError(error: unknown, context: string) {
        let errorMessage = '';
        if (error instanceof CustomError) {
            errorMessage = `${error.name}: ${error.message}`;
        } else if (error instanceof Error) {
            errorMessage = error.message;
        } else {
            errorMessage = 'Unknown error: ' + String(error);
        }

        console.error(`В методе: ${context} ошибка: ${errorMessage}`, error);
        showAlert({message: `${context}: ${errorMessage}`, type: 'error', duration: 0});
    }
}

export {ErrorHandler};
