<?php

namespace modules\settings\widgets\clear;

use modules\settings\widgets\clear\Assets;
use modules\user\components\Helper;
use yii\bootstrap5\Widget;
use yii\helpers\Url;

class InfoAndClearWidget extends Widget
{

    public function run()
    {
        Assets::register($this->view);

        $endpoints = [
            'flush' => '/settings/backend/clear/flush',
            'front-assets' => '/settings/backend/clear/front-assets',
            'back-assets' => '/settings/backend/clear/back-assets',
            'static-cache' => '/settings/backend/clear/static-cache',
            'logs' => '/settings/backend/clear/logs',
            'mails' => '/settings/backend/clear/mails',
            'debug' => '/settings/backend/clear/debug',
            'all' => '/settings/backend/clear/all',
            'get-size' => '/settings/backend/clear/get-size',
        ];

        $filteredEndpoints = array_filter($endpoints, function ($endpoint) {
            return Helper::checkRoute($endpoint);
        });

        return $this->render('index', [
            'endpoints' => $filteredEndpoints,
        ]);
    }
}
