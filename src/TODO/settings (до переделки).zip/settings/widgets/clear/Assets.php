<?php

namespace modules\settings\widgets\clear;

use yii\web\AssetBundle;

class Assets extends AssetBundle
{
    public $sourcePath = __DIR__ . '/media';

    public $css = ['css/clear.css'];

    public $js = ['js/dist/index.js'];

    public $jsOptions = [
        'type' => 'module',
    ];

}
