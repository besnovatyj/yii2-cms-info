<?php

use common\helpers\json\Encoder;

/** @var array $endpoints - Массив маршрутов для отправки запросов из JS */
?>
<div class="settings-module-clear-widget" data-endpoints='<?= Encoder::encode($endpoints) ?>'>

</div>
