<?php

namespace modules\settings;

class Module extends \common\components\module\BaseModule
{
    // public const EDITABLE = false;
    public const EDITABLE = YII_DEBUG;

    public static function getAdminMenu(): array
    {
        return require __DIR__ . '/config/adminMenu.php';
    }

    public static function getConfig(): array
    {
        return require __DIR__ . '/config/config.php';
    }

    public static function getOptions(): array
    {
        return require __DIR__ . '/config/options.php';
    }

    public static function getDependencies(): array
    {
        return require __DIR__ . '/config/dependencies.php';
    }

    public static function getSchema(): array
    {
        return require __DIR__ . '/config/schema.php';
    }

}
